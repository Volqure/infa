package slotmachine;

// Запускающий класс (нужен, чтобы NetBeans корректно стартовал JavaFX через Maven)
public class Launcher {
    public static void main(String[] args) {
        SlotMachineApp.main(args);
    }
}
