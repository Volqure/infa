package slotmachine;

import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.ParallelTransition;
import javafx.animation.PauseTransition;
import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.effect.MotionBlur;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

public class SlotController implements Initializable {

    // 0 - крестик, 1 - семерка, 2 - колокольчик, 3 - клевер
    private static final String[] SYMBOLS = {"✖", "7", "🔔", "☘"};
    private static final int CROSS = 0;
    private static final int SEVEN = 1;

    // порядок символов на ленте каждого барабана (у барабанов он разный, как в настоящем автомате)
    private static final int[][] ORDER = {{0, 1, 2, 3}, {3, 2, 1, 0}, {1, 3, 0, 2}};

    private static final double REEL_W = 140;
    private static final double REEL_H = 170;

    // ===== НАСТРОЙКИ УДАЧИ =====
    // После каждого проигрыша шанс гарантированного выигрыша растёт на LUCK_STEP,
    // но не больше LUCK_MAX. После выигрыша удача сбрасывается в 0.
    private static final double LUCK_STEP = 0.10;
    private static final double LUCK_MAX = 0.90;

    // плавное торможение барабана (быстро в начале, медленно в конце)
    private static final Interpolator CUBIC_OUT = new Interpolator() {
        @Override
        protected double curve(double t) {
            double u = 1 - t;
            return 1 - u * u * u;
        }
    };

    @FXML private Pane reel1;
    @FXML private Pane reel2;
    @FXML private Pane reel3;
    @FXML private Label resultLabel;
    @FXML private TextField betField;
    @FXML private Button spinButton;
    @FXML private Group lever;
    @FXML private Line leverArm;
    @FXML private Circle leverKnob;
    @FXML private Pane moneyLayer;
    @FXML private VBox machine;

    private static final double LEVER_LEN = 120;
    private static final double KNOB_R = 19;
    private static final double ARM_W = 9;

    private final Random rnd = new Random();
    // угол ручки в градусах: 0 - стоит вертикально вверх, ~145 - дёрнута вниз к игроку
    private final DoubleProperty leverAngle = new SimpleDoubleProperty(0);

    private final Label[] curLabels = new Label[3];
    private final Label[] nextLabels = new Label[3];
    private final Group[] content = new Group[3];
    private final MotionBlur[] blur = new MotionBlur[3];
    private final DoubleProperty[] reelPos = new DoubleProperty[3];
    private final double[] lastPos = new double[3];

    private Timeline flash;
    private ParallelTransition moneyRain;
    private boolean spinning = false;
    private double luck = 0;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        leverAngle.addListener((obs, oldV, newV) -> updateLever(newV.doubleValue()));
        updateLever(0);

        // в поле ставки можно вводить только цифры (до 9 знаков)
        betField.setTextFormatter(new TextFormatter<String>(change ->
                change.getControlNewText().matches("\\d{0,9}") ? change : null));

        Pane[] panes = {reel1, reel2, reel3};
        for (int r = 0; r < 3; r++) {
            final int rr = r;
            Pane pane = panes[r];
            pane.setMinSize(REEL_W, REEL_H);
            pane.setPrefSize(REEL_W, REEL_H);
            pane.setMaxSize(REEL_W, REEL_H);

            // две ячейки: текущая и следующая, они едут вниз по кругу, создавая эффект ленты
            curLabels[r] = makeCell();
            nextLabels[r] = makeCell();
            content[r] = new Group(curLabels[r], nextLabels[r]);
            blur[r] = new MotionBlur(90, 0);

            // тень сверху и снизу - эффект выпуклого барабана
            Rectangle shade = new Rectangle(REEL_W, REEL_H);
            shade.setArcWidth(20);
            shade.setArcHeight(20);
            shade.setMouseTransparent(true);
            shade.setFill(new LinearGradient(0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
                    new Stop(0.00, Color.rgb(0, 0, 0, 0.55)),
                    new Stop(0.28, Color.rgb(0, 0, 0, 0.0)),
                    new Stop(0.72, Color.rgb(0, 0, 0, 0.0)),
                    new Stop(1.00, Color.rgb(0, 0, 0, 0.55))));

            // окошко барабана: всё, что выезжает за рамку, обрезается
            Rectangle clip = new Rectangle(REEL_W, REEL_H);
            clip.setArcWidth(20);
            clip.setArcHeight(20);
            pane.setClip(clip);
            pane.getChildren().addAll(content[r], shade);

            reelPos[r] = new SimpleDoubleProperty(1);
            lastPos[r] = 1;
            reelPos[r].addListener((obs, oldV, newV) -> onReelMoved(rr, newV.doubleValue()));
            renderReel(r, 1);
        }
    }

    private Label makeCell() {
        Label l = new Label();
        l.setMinSize(REEL_W, REEL_H);
        l.setPrefSize(REEL_W, REEL_H);
        l.setMaxSize(REEL_W, REEL_H);
        l.setAlignment(Pos.CENTER);
        l.getStyleClass().add("symbol");
        return l;
    }

    private int symbolAt(int reel, int index) {
        return ORDER[reel][Math.floorMod(index, 4)];
    }

    // рисуем ленту барабана для позиции p (в "ячейках")
    private void renderReel(int r, double p) {
        double base = Math.floor(p);
        double f = p - base;
        int b = (int) base;
        curLabels[r].setText(SYMBOLS[symbolAt(r, b)]);
        curLabels[r].setTranslateY(f * REEL_H);
        nextLabels[r].setText(SYMBOLS[symbolAt(r, b + 1)]);
        nextLabels[r].setTranslateY((f - 1) * REEL_H);
    }

    private void onReelMoved(int r, double p) {
        renderReel(r, p);
        // размытие зависит от скорости вращения
        double speed = Math.abs(p - lastPos[r]) * REEL_H;
        lastPos[r] = p;
        if (speed < 4) {
            content[r].setEffect(null);
        } else {
            blur[r].setRadius(Math.min(24, speed * 0.5));
            content[r].setEffect(blur[r]);
        }
    }

    @FXML
    private void onSpin() {
        if (spinning) {
            return;
        }
        long bet = parseBet();
        if (bet <= 0) {
            showBetError();
            return;
        }

        spinning = true;
        spinButton.setDisable(true);
        resetResult();
        pullLever();
        shakeMachine();

        final int[] result = rollResult();
        for (int r = 0; r < 3; r++) {
            spinReel(r, result[r], result);
        }
    }

    // Выбор результата. Чем больше подряд проигрышей, тем выше шанс гарантированной победы.
    private int[] rollResult() {
        if (rnd.nextDouble() < luck) {
            int s = 1 + rnd.nextInt(3); // 7, колокольчик или клевер (кресты - не выигрыш)
            return new int[]{s, s, s};
        }
        return new int[]{rnd.nextInt(4), rnd.nextInt(4), rnd.nextInt(4)};
    }

    // Настоящее вращение ленты барабана: разгон, быстрое вращение, плавное торможение и "отскок"
    private void spinReel(int r, int desired, int[] result) {
        DoubleProperty pos = reelPos[r];
        double p0 = Math.rint(pos.get());
        int durationMs = 1300 + 500 * r;   // барабаны останавливаются по очереди
        int minCells = 12 + 5 * r;         // сколько ячеек минимум пролетит

        int j = 0;
        for (int i = 0; i < 4; i++) {
            if (ORDER[r][i] == desired) {
                j = i;
            }
        }
        int k = minCells + Math.floorMod(j - ((int) p0 + minCells), 4);
        double end = p0 + k;

        Timeline t = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(pos, p0)),
                // небольшой "замах" назад перед раскруткой
                new KeyFrame(Duration.millis(160), new KeyValue(pos, p0 - 0.25, Interpolator.EASE_OUT)),
                // вращение с торможением, чуть проскакиваем нужный символ
                new KeyFrame(Duration.millis(160 + durationMs), new KeyValue(pos, end + 0.12, CUBIC_OUT)),
                // возврат на место
                new KeyFrame(Duration.millis(160 + durationMs + 170), new KeyValue(pos, end, Interpolator.EASE_BOTH)));
        t.setDelay(Duration.millis(380)); // барабаны стартуют, когда ручка дошла до упора
        if (r == 2) {
            t.setOnFinished(e -> finishSpin(result));
        }
        t.play();
    }

    // Ручка - это стержень, который вращается вокруг основания. Мы смотрим на неё спереди,
    // поэтому при наклоне к игроку стержень укорачивается (cos), а шарик становится
    // крупнее, потому что приближается к нам (sin). Так движение выглядит объёмным.
    private void updateLever(double deg) {
        double th = Math.toRadians(deg);
        double x = 8 * Math.sin(th);                 // чуть уходит в сторону по дуге
        double y = -LEVER_LEN * Math.cos(th);        // проекция длины стержня
        double near = Math.sin(th);                  // >0 - ближе к игроку, <0 - дальше

        leverArm.setEndX(x);
        leverArm.setEndY(y);
        leverArm.setStrokeWidth(ARM_W * (1 + 0.18 * near));
        leverKnob.setCenterX(x);
        leverKnob.setCenterY(y);
        leverKnob.setRadius(KNOB_R * (1 + 0.30 * near));
    }

    // Анимация ручки: откат назад для замаха, ускоряющийся рывок вниз, упор, пружинистый возврат
    private void pullLever() {
        Timeline t = new Timeline(
                leverFrame(0, 0, Interpolator.LINEAR),
                leverFrame(130, -8, Interpolator.EASE_BOTH),     // наклон назад (замах)
                leverFrame(380, 148, Interpolator.EASE_IN),      // ускоряющийся рывок вниз
                leverFrame(440, 139, Interpolator.EASE_OUT),     // отскок от упора
                leverFrame(600, 141, Interpolator.EASE_BOTH),    // удерживается внизу
                leverFrame(620, 141, Interpolator.LINEAR),
                leverFrame(900, -14, Interpolator.EASE_OUT),     // пружина возвращает с перелётом
                leverFrame(1010, 7, Interpolator.EASE_BOTH),     // затухающие покачивания
                leverFrame(1100, -3, Interpolator.EASE_BOTH),
                leverFrame(1170, 1.5, Interpolator.EASE_BOTH),
                leverFrame(1240, 0, Interpolator.EASE_BOTH));
        t.play();
    }

    private KeyFrame leverFrame(double ms, double angle, Interpolator ip) {
        return new KeyFrame(Duration.millis(ms), new KeyValue(leverAngle, angle, ip));
    }

    // автомат слегка вздрагивает в момент, когда ручка дошла до низа
    private void shakeMachine() {
        Timeline s = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(machine.translateXProperty(), 0)),
                new KeyFrame(Duration.millis(40), new KeyValue(machine.translateXProperty(), 6)),
                new KeyFrame(Duration.millis(90), new KeyValue(machine.translateXProperty(), -5)),
                new KeyFrame(Duration.millis(140), new KeyValue(machine.translateXProperty(), 4)),
                new KeyFrame(Duration.millis(190), new KeyValue(machine.translateXProperty(), -3)),
                new KeyFrame(Duration.millis(240), new KeyValue(machine.translateXProperty(), 2)),
                new KeyFrame(Duration.millis(290), new KeyValue(machine.translateXProperty(), 0)));
        s.setDelay(Duration.millis(370));
        s.play();
    }

    private long parseBet() {
        String text = betField.getText();
        if (text == null || text.isEmpty()) {
            return 0;
        }
        try {
            return Long.parseLong(text);
        } catch (NumberFormatException ex) {
            return 0;
        }
    }

    private void showBetError() {
        if (!betField.getStyleClass().contains("error")) {
            betField.getStyleClass().add("error");
        }
        TranslateTransition shake = new TranslateTransition(Duration.millis(50), betField);
        shake.setByX(8);
        shake.setCycleCount(6);
        shake.setAutoReverse(true);
        shake.setOnFinished(e -> betField.setTranslateX(0));
        shake.play();

        PauseTransition pause = new PauseTransition(Duration.millis(700));
        pause.setOnFinished(e -> betField.getStyleClass().remove("error"));
        pause.play();
    }

    private void finishSpin(int[] r) {
        boolean three = r[0] == r[1] && r[1] == r[2];

        if (three && r[0] == CROSS) {
            showResult("GAME OVER", false);
            luck = Math.min(LUCK_MAX, luck + LUCK_STEP);
        } else if (three && r[0] == SEVEN) {
            showResult("JACKPOT", true);
            startMoneyRain();
            luck = 0;
        } else if (three) {
            showResult("WIN", true);
            startMoneyRain();
            luck = 0;
        } else {
            showResult("WASTED", false);
            luck = Math.min(LUCK_MAX, luck + LUCK_STEP);
        }

        spinning = false;
        spinButton.setDisable(false);
    }

    private void showResult(String text, boolean win) {
        resultLabel.setText(text);
        if (win) {
            // мигающая надпись
            flash = new Timeline(
                    new KeyFrame(Duration.ZERO, new KeyValue(resultLabel.opacityProperty(), 1)),
                    new KeyFrame(Duration.millis(350), new KeyValue(resultLabel.opacityProperty(), 0.05)));
            flash.setAutoReverse(true);
            flash.setCycleCount(Animation.INDEFINITE);
            flash.play();
        } else {
            // проигрыш - красный текст без мигания
            resultLabel.getStyleClass().add("lose");
        }
    }

    private void resetResult() {
        if (flash != null) {
            flash.stop();
        }
        resultLabel.setOpacity(1);
        resultLabel.setText(" ");
        resultLabel.getStyleClass().remove("lose");
        stopMoneyRain();
    }

    // падение денег сверху окна, 5 секунд
    private void startMoneyRain() {
        stopMoneyRain();
        double w = moneyLayer.getWidth();
        double h = moneyLayer.getHeight();

        moneyRain = new ParallelTransition();
        for (int i = 0; i < 45; i++) {
            Label bill = new Label("$");
            bill.getStyleClass().add("bill");
            bill.setLayoutX(rnd.nextDouble() * (w - 60));
            bill.setLayoutY(-70);
            moneyLayer.getChildren().add(bill);

            TranslateTransition fall = new TranslateTransition(Duration.seconds(2.5), bill);
            fall.setToY(h + 140);
            fall.setInterpolator(Interpolator.LINEAR);

            RotateTransition spin = new RotateTransition(Duration.seconds(2.5), bill);
            spin.setByAngle((rnd.nextBoolean() ? 1 : -1) * (180 + rnd.nextInt(360)));
            spin.setInterpolator(Interpolator.LINEAR);

            ParallelTransition one = new ParallelTransition(fall, spin);
            one.setDelay(Duration.millis(rnd.nextInt(2500))); // задержка + 2.5 c падения = макс. 5 c
            moneyRain.getChildren().add(one);
        }
        moneyRain.setOnFinished(e -> moneyLayer.getChildren().clear());
        moneyRain.play();
    }

    private void stopMoneyRain() {
        if (moneyRain != null) {
            moneyRain.stop();
            moneyRain = null;
        }
        moneyLayer.getChildren().clear();
    }
}
